export const imageArray = [
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    },
    {
        url: "https://randomuser.me/api/portraits/men/1.jpg",
        alt: "Image 1",
        universityName: "University A",
        logo: "https://via.placeholder.com/150?text=Logo+A"
    },
    {
        url: "https://randomuser.me/api/portraits/men/2.jpg",
        alt: "Image 2",
        universityName: "University B",
        logo: "https://via.placeholder.com/150?text=Logo+B"
    },
    {
        url: "https://randomuser.me/api/portraits/men/3.jpg",
        alt: "Image 3",
        universityName: "University C",
        logo: "https://via.placeholder.com/150?text=Logo+C"
    },
    {
        url: "https://randomuser.me/api/portraits/men/4.jpg",
        alt: "Image 4",
        universityName: "University D",
        logo: "https://via.placeholder.com/150?text=Logo+D"
    },
    {
        url: "https://randomuser.me/api/portraits/men/5.jpg",
        alt: "Image 5",
        universityName: "University E",
        logo: "https://via.placeholder.com/150?text=Logo+E"
    },
    {
        url: "https://randomuser.me/api/portraits/men/6.jpg",
        alt: "Image 6",
        universityName: "University F",
        logo: "https://via.placeholder.com/150?text=Logo+F"
    },
    {
        url: "https://randomuser.me/api/portraits/men/7.jpg",
        alt: "Image 7",
        universityName: "University G",
        logo: "https://via.placeholder.com/150?text=Logo+G"
    },
    {
        url: "https://randomuser.me/api/portraits/men/8.jpg",
        alt: "Image 8",
        universityName: "University H",
        logo: "https://via.placeholder.com/150?text=Logo+H"
    },
    {
        url: "https://randomuser.me/api/portraits/men/9.jpg",
        alt: "Image 9",
        universityName: "University I",
        logo: "https://via.placeholder.com/150?text=Logo+I"
    },
    {
        url: "https://randomuser.me/api/portraits/men/10.jpg",
        alt: "Image 10",
        universityName: "University J",
        logo: "https://via.placeholder.com/150?text=Logo+J"
    },
    {
        url: "https://randomuser.me/api/portraits/men/11.jpg",
        alt: "Image 11",
        universityName: "University K",
        logo: "https://via.placeholder.com/150?text=Logo+K"
    },
    {
        url: "https://randomuser.me/api/portraits/men/12.jpg",
        alt: "Image 12",
        universityName: "University L",
        logo: "https://via.placeholder.com/150?text=Logo+L"
    },
    {
        url: "https://randomuser.me/api/portraits/men/13.jpg",
        alt: "Image 13",
        universityName: "University M",
        logo: "https://via.placeholder.com/150?text=Logo+M"
    },
    {
        url: "https://randomuser.me/api/portraits/men/14.jpg",
        alt: "Image 14",
        universityName: "University N",
        logo: "https://via.placeholder.com/150?text=Logo+N"
    },
    {
        url: "https://randomuser.me/api/portraits/men/15.jpg",
        alt: "Image 15",
        universityName: "University O",
        logo: "https://via.placeholder.com/150?text=Logo+O"
    },
    {
        url: "https://randomuser.me/api/portraits/men/16.jpg",
        alt: "Image 16",
        universityName: "University P",
        logo: "https://via.placeholder.com/150?text=Logo+P"
    },
    {
        url: "https://randomuser.me/api/portraits/men/17.jpg",
        alt: "Image 17",
        universityName: "University Q",
        logo: "https://via.placeholder.com/150?text=Logo+Q"
    },
    {
        url: "https://randomuser.me/api/portraits/men/18.jpg",
        alt: "Image 18",
        universityName: "University R",
        logo: "https://via.placeholder.com/150?text=Logo+R"
    }
];