import React from 'react'
import PricingComponent from '../Components/Services/Plans'
import EnrollServices from '../Components/Services/EnrollServices'
import SocialLinks from '../Components/Services/SocialLinks'
import Reviews from '../Components/Services/Reviews'
import Root from '../Components/Helper/Root'

const Services = () => {
    return (
        <>
            <Root>

                <PricingComponent />
                <EnrollServices />
                <SocialLinks />
                <Reviews />
            </Root>
        </>
    )
}

export default Services