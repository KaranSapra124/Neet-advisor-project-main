import React from 'react'
import Root from "../Components/Helper/Root"
import Hero from '../Components/Contact/Hero'
const Contact = () => {
    return (
        <>
            <Root>
                <Hero />
            </Root>
        </>
    )
}

export default Contact